Hi,my dear friend:
Welcome to lumi opencloud-sdk
Before you use th opencloud-sdk,please read the "开方平台-NOAccount-API documentation"(Chinese) or "AIOT opencloud-API documentation-en.docx"(English)
and you have to get the Appid、Appkey、url
then,please open the file BaseRequest,fill these three values into the file(BaseRequest)
OK,Now you can execute the test case.

---
###  sdk使用引用jar 包即可
```
<dependency>   
    <groupId>com.lumi.opencloud</groupId>   
    <artifactId>opencloud-sdk</artifactId>   
    <version>1.0-SNAPSHOT</version>   
</dependency>   
```