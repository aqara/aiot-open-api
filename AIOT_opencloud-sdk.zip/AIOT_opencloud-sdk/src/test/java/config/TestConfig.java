package config;

/**
 * @author : yifeng.jin
 * @Version : v1.0
 * @Description :
 * @Date : 2021/3/8 11:39 上午
 * Copyright (C) : Lumi United Technology Co., Ltd
 */
public class TestConfig {
    /**
     * your token
     */
    public static String Token = "xxxxxxx";

    /**
     * test hub
     */
    public static String HubDid = "lumi1.xxxxx";
    /**
     * test sub device
     */
    public static String SubDid = "lumi.xxxxx";

    /**
     * test model1
     */
    public static String model = "lumi.gateway.aqhm01";

    /**
     * test model2
     */
    public static String model2 = "lumi.plug.v2";
}