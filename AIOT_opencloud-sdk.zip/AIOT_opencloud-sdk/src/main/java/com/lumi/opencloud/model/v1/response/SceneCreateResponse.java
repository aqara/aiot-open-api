package com.lumi.opencloud.model.v1.response;

import lombok.Data;

/**
 * @author lvyl
 * @date 2019/7/17 19:30
 * @description
 */
@Data
public class SceneCreateResponse {

    private String sceneId;
}
