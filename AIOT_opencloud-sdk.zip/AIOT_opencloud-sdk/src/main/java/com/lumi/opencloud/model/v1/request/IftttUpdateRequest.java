package com.lumi.opencloud.model.v1.request;

import com.lumi.opencloud.common.BaseRequest;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author : yifeng.jin
 * @Version : v1.0
 * @Description :
 * @Date : 2021/3/8 12:22 下午
 * Copyright (C) : Lumi United Technology Co., Ltd
 */
@Data
public class IftttUpdateRequest extends BaseRequest {
    private String userId;

    @NotEmpty(message = "linkageId can not be empty")
    private String linkageId;

    private String name;

    private String positionId;

    @Builder.Default
    private int conditionRelation = 1;

    private List<TriggerContentRequest> conditions;

    private List<ActionContentRequest> actions;

    @Builder.Default
    private int state = 1;

    @Override
    public String uri() {
        return null;
    }
}