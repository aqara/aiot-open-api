package com.lumi.opencloud.controller.v2;

import com.lumi.opencloud.common.AbstractConfig;
import com.lumi.opencloud.common.ResponseMsg;
import com.lumi.opencloud.manager.v2.SceneManager;
import com.lumi.opencloud.model.v2.request.SceneCreateRequest;
import com.lumi.opencloud.model.v2.request.SceneTryRequest;
import com.lumi.opencloud.model.v2.request.SceneUpdateRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * @author lvyl
 * @date 2019/7/16 18:06
 * @description
 */
@RestController
@RequestMapping(path = "/v2.0/open", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class OpenApiV2SceneTest extends AbstractConfig {

    private static Logger log = LoggerFactory.getLogger(OpenApiV2SceneTest.class);

    @PostMapping("/ifttt/scene/create")
    public ResponseMsg createScene(@RequestBody SceneCreateRequest request) {
        ResponseMsg responseMsg = SceneManager.createScene(configClientV2(),request);
        log.info("ifttt scene create responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @PostMapping("/ifttt/scene/update")
    public ResponseMsg updateScene(@RequestBody SceneUpdateRequest request) {
        ResponseMsg responseMsg = SceneManager.updateScene(configClientV2(),request);
        log.info("ifttt scene update responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/ifttt/scene/delete")
    public ResponseMsg deleteScene(@RequestParam String sceneId) {
        ResponseMsg responseMsg = SceneManager.deleteScene(configClientV2(),sceneId);
        log.info("ifttt scene delete responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @PostMapping("/ifttt/scene/try")
    public ResponseMsg tryScene(@RequestBody SceneTryRequest request) {
        ResponseMsg responseMsg = SceneManager.tryScene(configClientV2(),request);
        log.info("ifttt scene try responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/ifttt/scene/run")
    public ResponseMsg runScene(@RequestParam String sceneId) {
        ResponseMsg responseMsg = SceneManager.runScene(configClientV2(),sceneId);
        log.info("ifttt scene run responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/ifttt/scene/query/detail")
    public ResponseMsg queryDetailScene(@RequestParam String sceneId) {
        ResponseMsg responseMsg = SceneManager.queryDetailScene(configClientV2(),sceneId);
        log.info("ifttt scene query detail responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/ifttt/scene/subject/query")
    public ResponseMsg querySubjectScene(@RequestParam String subjectId) {
        ResponseMsg responseMsg = SceneManager.querySubjectScene(configClientV2(),subjectId);
        log.info("ifttt scene subject query responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }
}
