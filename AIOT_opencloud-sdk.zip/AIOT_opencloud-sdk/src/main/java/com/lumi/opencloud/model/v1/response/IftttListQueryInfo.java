package com.lumi.opencloud.model.v1.response;

import lombok.Data;

/**
 * @author lvyl
 * @date 2019/7/17 18:00
 * @description
 */
@Data
public class IftttListQueryInfo {

    private String iftttId;

    private String name;

    private int enable;
}
