package com.lumi.opencloud.controller.v2;

import com.lumi.opencloud.common.AbstractConfig;
import com.lumi.opencloud.common.ResponseMsg;
import com.lumi.opencloud.manager.v2.DeviceManager;
import com.lumi.opencloud.model.v2.response.DeviceBindQueryResponse;
import com.lumi.opencloud.model.v2.response.DeviceInfoResponse;
import com.lumi.opencloud.model.v2.response.DeviceQueryDetailResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author lvyl
 * @date 2019/7/16 18:06
 * @description
 */
@RestController
@RequestMapping(path = "/v2.0/open", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class OpenApiV2DeviceTest extends AbstractConfig {

    private static Logger log = LoggerFactory.getLogger(OpenApiV2DeviceTest.class);

    @GetMapping("/dev/bind/get")
    public ResponseMsg bindGetTest() {
        ResponseMsg responseMsg = DeviceManager.bindGet(configClientV2());
        log.info("bindGet responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/dev/bind/query")
    public ResponseMsg bindQuery(@RequestParam(required = false) String bindKey,@RequestParam(required = false) String did) {
        ResponseMsg<DeviceBindQueryResponse> responseMsg = DeviceManager.bindQuery(configClientV2(),bindKey,did);
        log.info("bind query responseMsg:{}",responseMsg.toString());
        return responseMsg;
    }

    @GetMapping("/dev/child/query")
    public ResponseMsg childQuery(@RequestParam String did) {
        ResponseMsg<List<DeviceQueryDetailResponse>> responseMsg = DeviceManager.childQuery(configClientV2(),did);
        log.info("child query responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/dev/connect/subdevice/start")
    public ResponseMsg connectSubdeviceStart(@RequestParam String did) {
        ResponseMsg responseMsg = DeviceManager.connectSubdeviceStart(configClientV2(),did,"");
        log.info("dev connect subdevice start responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/dev/connect/subdevice/stop")
    public ResponseMsg connectSubdeviceStop(@RequestParam String did) {
        ResponseMsg responseMsg = DeviceManager.connectSubdeviceStop(configClientV2(),did);
        log.info("dev connect subdevice stop responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/dev/unbind")
    public ResponseMsg unbindDev(@RequestParam String did,@RequestParam int option) {
        ResponseMsg responseMsg = DeviceManager.unbindDev(configClientV2(),did,option);
        log.info("dev unbind responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/dev/query/detail")
    public ResponseMsg detailQuery(@RequestParam List<String> dids) {
        ResponseMsg<List<DeviceInfoResponse>> responseMsg = DeviceManager.detailQuery(configClientV2(),dids);
        log.info("dev query detail responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/dev/timezone/update")
    public ResponseMsg updateTimeZone(@RequestParam List<String> dids,String timeZone) {
        ResponseMsg responseMsg = DeviceManager.updateTimeZone(configClientV2(),dids,timeZone);
        log.info("updateTimeZone responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

}
