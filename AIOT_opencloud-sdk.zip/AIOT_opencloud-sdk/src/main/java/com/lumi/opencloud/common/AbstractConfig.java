package com.lumi.opencloud.common;

/**
 * @author lvyl
 * @date 2019/7/19 12:01
 * @description
 */
public class AbstractConfig {

    public AiotConfig configClientV1(String token){
        return new AiotConfig(CustomConfig.Appid,CustomConfig.Appkey,token,CustomConfig.Lang,CustomConfig.DOMAIN_V1);
    }

    public AiotConfig configClientV2(){
        return new AiotConfig(CustomConfig.Appid,CustomConfig.Appkey,CustomConfig.Lang,CustomConfig.DOMAIN_V2);
    }
}
