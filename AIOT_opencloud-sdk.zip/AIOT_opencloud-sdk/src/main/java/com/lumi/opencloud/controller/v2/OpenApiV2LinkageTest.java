package com.lumi.opencloud.controller.v2;

import com.lumi.opencloud.common.AbstractConfig;
import com.lumi.opencloud.common.ResponseMsg;
import com.lumi.opencloud.manager.v2.LinkageManager;
import com.lumi.opencloud.model.v2.request.IftttCreateRequest;
import com.lumi.opencloud.model.v2.request.IftttUpdateRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author lvyl
 * @date 2019/7/16 18:06
 * @description
 */
@RestController
@RequestMapping(path = "/v2.0/open", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class OpenApiV2LinkageTest extends AbstractConfig {

    private static Logger log = LoggerFactory.getLogger(OpenApiV2LinkageTest.class);

    @GetMapping("/ifttt/trigger/definition/query")
    public ResponseMsg triggerDefinitionQuery(@RequestParam List<String> models) {
        ResponseMsg responseMsg = LinkageManager.triggerDefinitionQuery(configClientV2(),models);
        log.info("ifttt trigger definition query responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/ifttt/action/definition/query")
    public ResponseMsg actionDefinitionQuery(@RequestParam List<String> models) {
        ResponseMsg responseMsg = LinkageManager.actionDefinitionQuery(configClientV2(),models);
        log.info("ifttt action definition query responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @PostMapping("/ifttt/create")
    public ResponseMsg createIfttt(@RequestBody IftttCreateRequest request) {
        ResponseMsg responseMsg = LinkageManager.createIfttt(configClientV2(),request);
        log.info("ifttt create responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @PostMapping("/ifttt/update")
    public ResponseMsg updateIfttt(@RequestBody IftttUpdateRequest request) {
        ResponseMsg responseMsg = LinkageManager.updateIfttt(configClientV2(),request);
        log.info("ifttt update responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/ifttt/delete")
    public ResponseMsg deleteIfttt(@RequestParam String linkageId) {
        ResponseMsg responseMsg = LinkageManager.deleteIfttt(configClientV2(),linkageId);
        log.info("ifttt delete responseMsg:{}",responseMsg.toString());
        return responseMsg;
    }

    @GetMapping("/ifttt/state/update")
    public ResponseMsg enableIfttt(@RequestParam String linkageId,@RequestParam int state) {
        ResponseMsg responseMsg = LinkageManager.enableIfttt(configClientV2(),linkageId,state);
        log.info("ifttt enable responseMsg:{}",responseMsg.toString());
        return responseMsg;
    }

    @GetMapping("/ifttt/query/linkage/detail")
    public ResponseMsg queryDetail(@RequestParam String linkageId) {
        ResponseMsg responseMsg = LinkageManager.queryDetail(configClientV2(),linkageId);
        log.info("ifttt query detail responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }

    @GetMapping("/ifttt/subject/query")
    public ResponseMsg subjectQuery(@RequestParam String subjectId) {
        ResponseMsg responseMsg = LinkageManager.subjectQuery(configClientV2(),subjectId);
        log.info("ifttt subject query responseMsg:{}",responseMsg.toString());

        return responseMsg;
    }
}
